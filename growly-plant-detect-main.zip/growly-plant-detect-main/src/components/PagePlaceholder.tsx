import { Link } from "@tanstack/react-router";
import { LeafBackdrop } from "./LeafBackdrop";
import { BottomNav } from "./BottomNav";
import iconVoltar from "@/assets/icon-voltar.png.asset.json";

export function PagePlaceholder({ title, description }: { title: string; description: string }) {
  return (
    <div className="relative min-h-screen overflow-hidden bg-background pb-24">
      <LeafBackdrop />
      <Link
        to="/home"
        className="absolute top-6 left-4 z-20 flex h-10 w-10 items-center justify-center rounded-full bg-background/80 shadow-sm"
        aria-label="Voltar"
      >
        <img src={iconVoltar.url} alt="" className="h-5 w-5" />
      </Link>
      <main className="relative z-10 mx-auto flex w-full max-w-sm flex-col items-center px-6 pt-28 text-center">
        <h1 className="font-display text-3xl font-bold text-primary">{title}</h1>
        <p className="mt-3 text-sm text-primary/70">{description}</p>
        <p className="mt-10 rounded-2xl border border-dashed border-primary/30 px-6 py-8 text-sm text-primary/60">
          Em breve.
        </p>
      </main>
      <BottomNav />
    </div>
  );
}
