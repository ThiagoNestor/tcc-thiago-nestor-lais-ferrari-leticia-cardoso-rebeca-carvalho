import { Link, useRouterState } from "@tanstack/react-router";
import iconHome from "@/assets/icon-home.png.asset.json";
import iconPesquisar from "@/assets/icon-pesquisar.png.asset.json";
import iconEden from "@/assets/icon-eden.png.asset.json";
import iconSuporte from "@/assets/icon-suporte.png.asset.json";
import iconConfig from "@/assets/icon-config.png.asset.json";

const items = [
  { to: "/home", icon: iconHome.url, label: "Início" },
  { to: "/explorar", icon: iconPesquisar.url, label: "Explorar" },
  { to: "/eden", icon: iconEden.url, label: "Eden IA" },
  { to: "/suporte", icon: iconSuporte.url, label: "Suporte" },
  { to: "/configuracoes", icon: iconConfig.url, label: "Configurações" },
] as const;

export function BottomNav() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-20 border-t border-primary/15 bg-background/95 backdrop-blur">
      <ul className="mx-auto flex max-w-md items-center justify-between px-6 py-3">
        {items.map((it) => {
          const active = pathname === it.to;
          return (
            <li key={it.to}>
              <Link
                to={it.to}
                className={`flex flex-col items-center gap-1 text-[10px] font-semibold transition ${
                  active ? "text-primary" : "text-primary/60 hover:text-primary"
                }`}
              >
                <img src={it.icon} alt="" className="h-6 w-6" />
                <span>{it.label}</span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
