import topLeft from "@/assets/leaves-top-left.png.asset.json";
import topRight from "@/assets/leaves-top-right.png.asset.json";
import bottomRight from "@/assets/leaves-bottom-right.png.asset.json";

export function LeafBackdrop() {
  return (
    <>
      <img
        src={topLeft.url}
        alt=""
        aria-hidden
        className="pointer-events-none select-none absolute top-0 left-0 w-40 sm:w-52"
      />
      <img
        src={topRight.url}
        alt=""
        aria-hidden
        className="pointer-events-none select-none absolute top-0 right-0 w-32 sm:w-40"
      />
      <img
        src={bottomRight.url}
        alt=""
        aria-hidden
        className="pointer-events-none select-none absolute bottom-0 right-0 w-44 sm:w-56"
      />
    </>
  );
}
