import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { LeafBackdrop } from "./LeafBackdrop";
import logoInicio from "@/assets/logo-inicio.png.asset.json";

export function AuthShell({ children }: { children: ReactNode }) {
  return (
    <div className="relative min-h-screen overflow-hidden bg-background">
      <LeafBackdrop />
      <main className="relative z-10 mx-auto flex min-h-screen w-full max-w-sm flex-col items-center px-6 pt-20 pb-12">
        <Link to="/" className="block">
          <img
            src={logoInicio.url}
            alt="Growly — Onde cada planta encontra seu caminho para florescer"
            className="w-64 sm:w-72"
          />
        </Link>
        <div className="mt-14 w-full">{children}</div>
      </main>
    </div>
  );
}
