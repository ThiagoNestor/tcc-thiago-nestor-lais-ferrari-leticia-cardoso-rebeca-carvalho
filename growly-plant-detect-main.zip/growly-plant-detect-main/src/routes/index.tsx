import { createFileRoute, Link } from "@tanstack/react-router";
import { AuthShell } from "../components/AuthShell";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Growly — Identifique PANCs com IA" },
      {
        name: "description",
        content:
          "Growly: descubra, identifique e cuide de Plantas Alimentícias Não Convencionais com inteligência artificial.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <AuthShell>
      <div className="flex flex-col items-center gap-4">
        <Link
          to="/login"
          className="w-56 rounded-full bg-secondary py-3 text-center text-base font-semibold text-secondary-foreground shadow-sm transition hover:bg-secondary/80"
        >
          Login
        </Link>

        <span className="text-sm font-medium text-primary/70">Ou</span>

        <Link
          to="/cadastro"
          className="w-56 rounded-full bg-secondary py-3 text-center text-base font-semibold text-secondary-foreground shadow-sm transition hover:bg-secondary/80"
        >
          Cadastre-se
        </Link>
      </div>
    </AuthShell>
  );
}
