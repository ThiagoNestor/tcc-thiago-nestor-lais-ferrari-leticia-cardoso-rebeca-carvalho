import { createFileRoute } from "@tanstack/react-router";
import { PagePlaceholder } from "@/components/PagePlaceholder";

export const Route = createFileRoute("/configuracoes")({
  head: () => ({ meta: [{ title: "Configurações — Growly" }] }),
  component: () => (
    <PagePlaceholder title="Configurações" description="Ajuste sua conta e preferências." />
  ),
});
