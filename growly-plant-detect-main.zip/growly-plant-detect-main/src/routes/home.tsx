import { createFileRoute, Link } from "@tanstack/react-router";
import { LeafBackdrop } from "@/components/LeafBackdrop";
import { BottomNav } from "@/components/BottomNav";
import logoMenu from "@/assets/logo-menu.png.asset.json";
import cardIdentificar from "@/assets/card-identificar.png.asset.json";
import cardExplorar from "@/assets/card-explorar.png.asset.json";
import cardJardim from "@/assets/card-jardim.png.asset.json";

export const Route = createFileRoute("/home")({
  head: () => ({
    meta: [
      { title: "Growly — Início" },
      { name: "description", content: "Identifique, explore e cultive PANCs com o Growly." },
    ],
  }),
  component: Home,
});

type CardProps = {
  to: string;
  title: string;
  image: string;
};

function ActionCard({ to, title, image }: CardProps) {
  return (
    <Link
      to={to}
      className="group relative block overflow-hidden rounded-2xl border border-primary/20 bg-background shadow-sm transition hover:shadow-md"
    >
      <div className="flex items-center justify-between gap-3 p-5">
        <h2 className="font-display text-lg font-semibold text-primary">{title}</h2>
        <img
          src={image}
          alt=""
          aria-hidden
          className="h-20 w-32 shrink-0 object-cover object-right"
        />
      </div>
    </Link>
  );
}

function Home() {
  return (
    <div className="relative min-h-screen overflow-hidden bg-background pb-24">
      <LeafBackdrop />

      <header className="relative z-10 flex flex-col items-center pt-10">
        <img src={logoMenu.url} alt="Growly" className="h-10" />
      </header>

      <main className="relative z-10 mx-auto mt-10 flex w-full max-w-sm flex-col gap-5 px-6">
        <ActionCard to="/identificar" title="Identificar Planta" image={cardIdentificar.url} />
        <ActionCard to="/explorar" title="Explorar Plantas" image={cardExplorar.url} />
        <ActionCard to="/jardim" title="Meu Jardim" image={cardJardim.url} />
      </main>

      <BottomNav />
    </div>
  );
}
