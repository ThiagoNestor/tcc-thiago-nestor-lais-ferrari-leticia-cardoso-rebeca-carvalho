import { createFileRoute } from "@tanstack/react-router";
import { PagePlaceholder } from "@/components/PagePlaceholder";

export const Route = createFileRoute("/jardim")({
  head: () => ({ meta: [{ title: "Meu Jardim — Growly" }] }),
  component: () => (
    <PagePlaceholder title="Meu Jardim" description="Acompanhe as plantas que você cultiva." />
  ),
});
