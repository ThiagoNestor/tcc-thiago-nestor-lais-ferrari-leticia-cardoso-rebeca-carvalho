import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { LeafBackdrop } from "../components/LeafBackdrop";
import logoMenu from "@/assets/logo-menu.png.asset.json";
import iconCamera from "@/assets/icon-camera.png.asset.json";
import iconVoltar from "@/assets/icon-voltar.png.asset.json";

export const Route = createFileRoute("/identificar")({
  head: () => ({
    meta: [
      { title: "Identificar — Growly" },
      {
        name: "description",
        content: "Use a câmera para identificar PANCs com a IA do Growly.",
      },
    ],
  }),
  component: IdentificarPage,
});

function IdentificarPage() {
  const navigate = useNavigate();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [capture, setCapture] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    let cancelled = false;
    async function start() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "environment" },
          audio: false,
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (e) {
        setError(
          "Não foi possível acessar a câmera. Verifique as permissões do navegador.",
        );
        console.error(e);
      }
    }
    if (!capture) start();
    return () => {
      cancelled = true;
      streamRef.current?.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    };
  }, [capture]);

  function takePhoto() {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext("2d")?.drawImage(video, 0, 0);
    setCapture(canvas.toDataURL("image/jpeg", 0.92));
    streamRef.current?.getTracks().forEach((t) => t.stop());
  }

  return (
    <div className="relative min-h-screen overflow-hidden bg-background">
      <LeafBackdrop />

      <header className="relative z-10 flex items-center justify-between px-5 pt-6">
        <button
          type="button"
          onClick={() => navigate({ to: "/" })}
          aria-label="Voltar"
          className="rounded-full p-1 transition hover:bg-primary/5"
        >
          <img src={iconVoltar.url} alt="" className="h-7 w-7" />
        </button>
        <img src={logoMenu.url} alt="Growly" className="h-9" />
        <span className="w-7" />
      </header>

      <main className="relative z-10 mx-auto flex w-full max-w-md flex-col items-center px-6 pt-8 pb-12">
        <h2 className="font-display text-3xl font-bold text-primary">Identificar</h2>
        <p className="mt-2 text-center text-sm text-primary/75">
          Aponte a câmera para a folha ou planta que deseja identificar.
        </p>

        <div className="mt-8 aspect-[3/4] w-full overflow-hidden rounded-3xl border-4 border-primary/80 bg-primary/10 shadow-lg">
          {capture ? (
            <img src={capture} alt="Foto capturada" className="h-full w-full object-cover" />
          ) : error ? (
            <div className="flex h-full w-full items-center justify-center p-6 text-center text-sm text-primary">
              {error}
            </div>
          ) : (
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="h-full w-full object-cover"
            />
          )}
        </div>
        <canvas ref={canvasRef} className="hidden" />

        <div className="mt-8 flex items-center gap-6">
          {capture ? (
            <>
              <button
                type="button"
                onClick={() => setCapture(null)}
                className="rounded-full bg-secondary px-6 py-3 text-sm font-semibold text-secondary-foreground shadow-sm transition hover:bg-secondary/80"
              >
                Tirar outra
              </button>
              <button
                type="button"
                onClick={() => console.log("analisar", capture?.slice(0, 32))}
                className="rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow-sm transition hover:bg-primary/90"
              >
                Identificar planta
              </button>
            </>
          ) : (
            <button
              type="button"
              onClick={takePhoto}
              disabled={!!error}
              aria-label="Tirar foto"
              className="flex h-20 w-20 items-center justify-center rounded-full bg-primary shadow-lg ring-4 ring-primary/20 transition hover:scale-105 disabled:opacity-50"
            >
              <img src={iconCamera.url} alt="" className="h-10 w-10 invert" />
            </button>
          )}
        </div>
      </main>
    </div>
  );
}
