import { createFileRoute } from "@tanstack/react-router";
import { PagePlaceholder } from "@/components/PagePlaceholder";

export const Route = createFileRoute("/explorar")({
  head: () => ({ meta: [{ title: "Explorar Plantas — Growly" }] }),
  component: () => (
    <PagePlaceholder title="Explorar Plantas" description="Descubra PANCs e suas propriedades." />
  ),
});
