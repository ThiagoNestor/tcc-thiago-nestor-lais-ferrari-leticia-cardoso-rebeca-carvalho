import { createFileRoute } from "@tanstack/react-router";
import { PagePlaceholder } from "@/components/PagePlaceholder";

export const Route = createFileRoute("/eden")({
  head: () => ({ meta: [{ title: "Eden IA — Growly" }] }),
  component: () => (
    <PagePlaceholder title="Eden IA" description="Sua assistente inteligente para plantas." />
  ),
});
