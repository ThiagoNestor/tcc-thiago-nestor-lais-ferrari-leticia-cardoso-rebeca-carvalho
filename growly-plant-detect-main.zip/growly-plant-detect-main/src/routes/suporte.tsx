import { createFileRoute } from "@tanstack/react-router";
import { PagePlaceholder } from "@/components/PagePlaceholder";

export const Route = createFileRoute("/suporte")({
  head: () => ({ meta: [{ title: "Suporte — Growly" }] }),
  component: () => (
    <PagePlaceholder title="Suporte" description="Encontre respostas e fale conosco." />
  ),
});
