import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { AuthShell } from "../components/AuthShell";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Entrar — Growly" },
      { name: "description", content: "Acesse sua conta Growly para cuidar das suas plantas." },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    // TODO: integrar autenticação
    console.log("login", { identifier, password });
    navigate({ to: "/home" });
  }

  return (
    <AuthShell>
      <form onSubmit={onSubmit} className="flex flex-col gap-5">
        <Field
          label="Email ou Nome de Usuário"
          value={identifier}
          onChange={setIdentifier}
          type="text"
          autoComplete="username"
        />
        <Field
          label="Senha"
          value={password}
          onChange={setPassword}
          type="password"
          autoComplete="current-password"
        />

        <button
          type="submit"
          className="mt-2 w-full rounded-full bg-secondary py-3 text-base font-semibold text-secondary-foreground shadow-sm transition hover:bg-secondary/80"
        >
          Login
        </button>

        <p className="mt-4 text-center text-sm text-primary/80">
          Ainda não tem uma conta?{" "}
          <Link to="/cadastro" className="font-bold text-primary underline-offset-2 hover:underline">
            Cadastre-se
          </Link>
        </p>
      </form>
    </AuthShell>
  );
}

function Field({
  label,
  value,
  onChange,
  type,
  autoComplete,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type: string;
  autoComplete?: string;
}) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-sm font-medium text-primary">{label}</span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        autoComplete={autoComplete}
        required
        className="h-11 rounded-full bg-[var(--color-input-field)] px-5 text-base text-primary outline-none ring-0 transition focus:ring-2 focus:ring-primary/40"
      />
    </label>
  );
}
