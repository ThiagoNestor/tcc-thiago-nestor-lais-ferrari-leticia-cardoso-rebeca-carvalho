import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { AuthShell } from "../components/AuthShell";

export const Route = createFileRoute("/cadastro")({
  head: () => ({
    meta: [
      { title: "Cadastro — Growly" },
      { name: "description", content: "Crie sua conta Growly e comece a identificar PANCs." },
    ],
  }),
  component: CadastroPage,
});

function CadastroPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    console.log("cadastro", { email, username, password });
    navigate({ to: "/login" });
  }

  return (
    <AuthShell>
      <form onSubmit={onSubmit} className="flex flex-col gap-4">
        <Field label="Email" value={email} onChange={setEmail} type="email" autoComplete="email" />
        <Field
          label="Nome de Usuário"
          value={username}
          onChange={setUsername}
          type="text"
          autoComplete="username"
        />
        <Field
          label="Senha"
          value={password}
          onChange={setPassword}
          type="password"
          autoComplete="new-password"
        />

        <button
          type="submit"
          className="mt-3 w-full rounded-full bg-secondary py-3 text-base font-semibold text-secondary-foreground shadow-sm transition hover:bg-secondary/80"
        >
          Cadastrar
        </button>

        <p className="mt-4 text-center text-sm text-primary/80">
          Já possui uma conta?{" "}
          <Link to="/login" className="font-bold text-primary underline-offset-2 hover:underline">
            Fazer login
          </Link>
        </p>
      </form>
    </AuthShell>
  );
}

function Field({
  label,
  value,
  onChange,
  type,
  autoComplete,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type: string;
  autoComplete?: string;
}) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-sm font-medium text-primary">{label}</span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        autoComplete={autoComplete}
        required
        className="h-11 rounded-full bg-[var(--color-input-field)] px-5 text-base text-primary outline-none transition focus:ring-2 focus:ring-primary/40"
      />
    </label>
  );
}
